import { useState, useEffect } from 'react';

export type Language = 'en' | 'ar';

interface Translations {
  [key: string]: {
    en: string;
    ar: string;
  };
}

export const translations: Translations = {
  // Header
  'app.title': {
    en: 'RoAi',
    ar: 'روي'
  },
  'nav.dashboard': {
    en: 'Dashboard',
    ar: 'لوحة التحكم'
  },
  'nav.contentGenerator': {
    en: 'Content Generator',
    ar: 'منشئ المحتوى'
  },
  'nav.marketingTools': {
    en: 'Marketing Tools',
    ar: 'أدوات التسويق'
  },
  'nav.analytics': {
    en: 'Analytics',
    ar: 'التحليلات'
  },
  'nav.aiChat': {
    en: 'AI Assistant',
    ar: 'المساعد الذكي'
  },
  'nav.merchants': {
    en: 'For Merchants',
    ar: 'للتجار'
  },
  'nav.profile': {
    en: 'Profile',
    ar: 'الملف الشخصي'
  },
  
  // Dashboard
  'dashboard.welcome': {
    en: 'Welcome back',
    ar: 'مرحباً بعودتك'
  },
  'dashboard.subtitle': {
    en: "Let's create amazing content for your business today.",
    ar: 'دعنا ننشئ محتوى رائع لعملك اليوم.'
  },
  'dashboard.contentGenerated': {
    en: 'Content Generated',
    ar: 'المحتوى المُنشأ'
  },
  'dashboard.campaigns': {
    en: 'Campaigns Created',
    ar: 'الحملات المُنشأة'
  },
  'dashboard.suggestions': {
    en: 'AI Suggestions',
    ar: 'اقتراحات الذكاء الاصطناعي'
  },
  'dashboard.timeSaved': {
    en: 'Time Saved',
    ar: 'الوقت المُوفر'
  },
  
  // Content Generator
  'content.quickGeneration': {
    en: 'Quick Content Generation',
    ar: 'إنشاء المحتوى السريع'
  },
  'content.productDescription': {
    en: 'Product Description',
    ar: 'وصف المنتج'
  },
  'content.productDescriptionSubtitle': {
    en: 'Generate compelling product descriptions that convert',
    ar: 'إنشاء أوصاف منتجات مقنعة تحقق التحويل'
  },
  'content.socialAd': {
    en: 'Social Media Ad',
    ar: 'إعلان وسائل التواصل'
  },
  'content.socialAdSubtitle': {
    en: 'Create engaging social media advertisements',
    ar: 'إنشاء إعلانات جذابة لوسائل التواصل الاجتماعي'
  },
  'content.hashtags': {
    en: 'Hashtag Generator',
    ar: 'منشئ الهاشتاغ'
  },
  'content.hashtagsSubtitle': {
    en: 'Discover trending hashtags for your niche',
    ar: 'اكتشف الهاشتاغات الرائجة لمجالك'
  },
  'content.marketingStrategy': {
    en: 'Marketing Strategy',
    ar: 'استراتيجية التسويق'
  },
  'content.marketingStrategySubtitle': {
    en: 'Get AI-powered marketing recommendations',
    ar: 'احصل على توصيات تسويقية مدعومة بالذكاء الاصطناعي'
  },
  'content.aiGenerator': {
    en: 'AI Content Generator',
    ar: 'منشئ المحتوى بالذكاء الاصطناعي'
  },
  'content.contentType': {
    en: 'Content Type',
    ar: 'نوع المحتوى'
  },
  'content.productInfo': {
    en: 'Product/Business Information',
    ar: 'معلومات المنتج/العمل'
  },
  'content.productInfoPlaceholder': {
    en: 'Describe your product, service, or provide key details for content generation...',
    ar: 'اوصف منتجك أو خدمتك، أو قدم التفاصيل الأساسية لإنشاء المحتوى...'
  },
  'content.targetAudience': {
    en: 'Target Audience',
    ar: 'الجمهور المستهدف'
  },
  'content.targetAudiencePlaceholder': {
    en: 'e.g., Young professionals, 25-35',
    ar: 'مثلاً، المهنيون الشباب، 25-35 سنة'
  },
  'content.tone': {
    en: 'Tone of Voice',
    ar: 'نبرة الصوت'
  },
  'content.language': {
    en: 'Language',
    ar: 'اللغة'
  },
  'content.generating': {
    en: 'Generating Content...',
    ar: 'جاري إنشاء المحتوى...'
  },
  'content.generate': {
    en: 'Generate Content with AI',
    ar: 'إنشاء المحتوى بالذكاء الاصطناعي'
  },
  'content.generatedContent': {
    en: 'Generated Content',
    ar: 'المحتوى المُنشأ'
  },
  'content.copy': {
    en: 'Copy',
    ar: 'نسخ'
  },
  'content.export': {
    en: 'Export',
    ar: 'تصدير'
  },
  'content.suggestedHashtags': {
    en: 'Suggested Hashtags:',
    ar: 'الهاشتاغات المقترحة:'
  },
  'content.optimizationSuggestions': {
    en: 'Optimization Suggestions:',
    ar: 'اقتراحات التحسين:'
  },
  
  // Tones
  'tone.professional': {
    en: 'Professional',
    ar: 'مهني'
  },
  'tone.casual': {
    en: 'Casual & Friendly',
    ar: 'عادي وودود'
  },
  'tone.enthusiastic': {
    en: 'Enthusiastic',
    ar: 'متحمس'
  },
  'tone.luxury': {
    en: 'Luxury & Premium',
    ar: 'فاخر ومميز'
  },
  'tone.technical': {
    en: 'Technical & Informative',
    ar: 'تقني وإعلامي'
  },
  
  // Languages
  'language.english': {
    en: 'English',
    ar: 'الإنجليزية'
  },
  'language.arabic': {
    en: 'Arabic',
    ar: 'العربية'
  },
  
  // Business Profile
  'business.profile': {
    en: 'Business Profile',
    ar: 'ملف العمل'
  },
  'business.completion': {
    en: 'Profile Completion',
    ar: 'اكتمال الملف الشخصي'
  },
  'business.update': {
    en: 'Update Business Info',
    ar: 'تحديث معلومات العمل'
  },
  
  // Quick Tools
  'tools.quickTools': {
    en: 'Quick Tools',
    ar: 'الأدوات السريعة'
  },
  'tools.hashtagResearch': {
    en: 'Hashtag Research',
    ar: 'بحث الهاشتاغ'
  },
  'tools.hashtagResearchDesc': {
    en: 'Find trending hashtags',
    ar: 'العثور على الهاشتاغات الرائجة'
  },
  'tools.emailTemplates': {
    en: 'Email Templates',
    ar: 'قوالب البريد الإلكتروني'
  },
  'tools.emailTemplatesDesc': {
    en: 'Customer support responses',
    ar: 'ردود دعم العملاء'
  },
  'tools.brandGuidelines': {
    en: 'Brand Guidelines',
    ar: 'دليل العلامة التجارية'
  },
  'tools.brandGuidelinesDesc': {
    en: 'Colors & fonts',
    ar: 'الألوان والخطوط'
  },
  
  // Recent Activity
  'activity.recent': {
    en: 'Recent Activity',
    ar: 'النشاط الأخير'
  },
  'activity.noActivity': {
    en: 'No recent activity',
    ar: 'لا يوجد نشاط حديث'
  },
  'activity.viewAll': {
    en: 'View all activity',
    ar: 'عرض كل النشاط'
  },
  
  // Success Messages
  'success.contentGenerated': {
    en: 'Content Generated Successfully!',
    ar: 'تم إنشاء المحتوى بنجاح!'
  },
  'success.contentReady': {
    en: 'Your AI-generated content is ready.',
    ar: 'المحتوى المُنشأ بالذكاء الاصطناعي جاهز.'
  },
  'success.copied': {
    en: 'Copied!',
    ar: 'تم النسخ!'
  },
  'success.copiedDesc': {
    en: 'Content copied to clipboard.',
    ar: 'تم نسخ المحتوى إلى الحافظة.'
  },
  
  // Error Messages
  'error.generationFailed': {
    en: 'Generation Failed',
    ar: 'فشل الإنشاء'
  },
  'error.copyFailed': {
    en: 'Copy Failed',
    ar: 'فشل النسخ'
  },
  'error.copyFailedDesc': {
    en: 'Unable to copy to clipboard.',
    ar: 'غير قادر على النسخ إلى الحافظة.'
  },
  
  // AI Chat Assistant
  'chat.title': {
    en: 'AI Business Assistant',
    ar: 'مساعد الأعمال الذكي'
  },
  'chat.subtitle': {
    en: 'Get instant advice and support for your business',
    ar: 'احصل على نصائح ودعم فوري لعملك'
  },
  'chat.placeholder': {
    en: 'Ask me anything about your business...',
    ar: 'اسأل أي شيء عن عملك...'
  },
  'chat.send': {
    en: 'Send',
    ar: 'إرسال'
  },
  'chat.thinking': {
    en: 'AI is thinking...',
    ar: 'الذكاء الاصطناعي يفكر...'
  },
  'chat.welcomeMessage': {
    en: 'Hello! I\'m your personal AI business assistant. I can help you with marketing strategies, business advice, content ideas, and much more. What would you like to discuss today?',
    ar: 'مرحباً! أنا مساعدك الشخصي للأعمال بالذكاء الاصطناعي. يمكنني مساعدتك في استراتيجيات التسويق ونصائح الأعمال وأفكار المحتوى وأكثر من ذلك بكثير. ما الذي تريد مناقشته اليوم؟'
  }
};

export function useLanguage() {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'ar')) {
      setLanguage(savedLanguage);
    }
  }, []);

  const changeLanguage = (newLanguage: Language) => {
    setLanguage(newLanguage);
    localStorage.setItem('language', newLanguage);
    
    // Update document direction for RTL support
    document.documentElement.dir = newLanguage === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = newLanguage;
  };

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return { language, changeLanguage, t };
}