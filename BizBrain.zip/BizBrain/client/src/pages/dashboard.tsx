import { useState } from "react";
import { Header } from "@/components/header";
import { StatsCards } from "@/components/stats-cards";
import { ContentGenerator } from "@/components/content-generator";
import { BusinessProfile } from "@/components/business-profile";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/i18n";
import type { Business, Activity } from "@shared/schema";

export default function Dashboard() {
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const { t } = useLanguage();

  // Fetch businesses
  const { data: businesses = [] } = useQuery<Business[]>({
    queryKey: ["/api/businesses"],
  });

  // Fetch recent activities
  const { data: activities = [] } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });

  // Use first business as default
  const currentBusiness = selectedBusiness || businesses[0] || null;

  const { language } = useLanguage();
  const isArabic = language === 'ar';

  return (
    <div className={`min-h-screen bg-slate-50 ${isArabic ? 'rtl' : 'ltr'}`}>
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            {t('dashboard.welcome')}, {currentBusiness?.name ? `${currentBusiness.name} ${isArabic ? 'فريق' : 'team'}` : isArabic ? 'مرحباً' : 'there'}!
          </h1>
          <p className="text-slate-600">{t('dashboard.subtitle')}</p>
        </div>

        {/* Stats Cards */}
        <StatsCards />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2">
            <ContentGenerator currentBusiness={currentBusiness} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <BusinessProfile 
              business={currentBusiness} 
              onBusinessChange={setSelectedBusiness}
            />
            
            {/* Quick Tools */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="text-lg font-semibold text-slate-900 mb-4">
                {isArabic ? 'أدوات سريعة' : 'Quick Tools'}
              </h3>
              <div className="space-y-3">
                <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-slate-50 rounded-lg transition-colors duration-200">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i className="fas fa-hashtag text-blue-600 text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 text-sm">
                      {isArabic ? 'بحث الهاشتاقات' : 'Hashtag Research'}
                    </p>
                    <p className="text-xs text-slate-600">
                      {isArabic ? 'اكتشف الهاشتاقات الرائجة' : 'Find trending hashtags'}
                    </p>
                  </div>
                </button>

                <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-slate-50 rounded-lg transition-colors duration-200">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <i className="fas fa-envelope text-green-600 text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 text-sm">
                      {isArabic ? 'قوالب البريد الإلكتروني' : 'Email Templates'}
                    </p>
                    <p className="text-xs text-slate-600">Customer support responses</p>
                  </div>
                </button>

                <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-slate-50 rounded-lg transition-colors duration-200">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i className="fas fa-palette text-purple-600 text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 text-sm">Brand Guidelines</p>
                    <p className="text-xs text-slate-600">Colors & fonts</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Recent Activity</h3>
              <div className="space-y-4">
                {activities.length === 0 ? (
                  <p className="text-slate-600 text-sm">No recent activity</p>
                ) : (
                  activities.slice(0, 3).map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mt-0.5">
                        <i className="fas fa-file-alt text-primary-600 text-xs"></i>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900">{activity.description}</p>
                        <p className="text-xs text-slate-600 mt-1">
                          {activity.createdAt ? new Date(activity.createdAt).toLocaleDateString() : 'Recently'}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
              
              {activities.length > 3 && (
                <button className="w-full mt-4 text-sm text-primary-600 font-medium hover:text-primary-700 transition-colors duration-200">
                  View all activity
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Marketing Insights */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">AI Marketing Insights</h3>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start space-x-3">
                  <i className="fas fa-lightbulb text-blue-600 mt-1"></i>
                  <div>
                    <h4 className="font-medium text-blue-900">Optimization Tip</h4>
                    <p className="text-sm text-blue-800 mt-1">Your product descriptions perform 23% better when they include emotional triggers. Try adding words like "transform," "experience," or "discover."</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start space-x-3">
                  <i className="fas fa-trending-up text-green-600 mt-1"></i>
                  <div>
                    <h4 className="font-medium text-green-900">Trending Keywords</h4>
                    <p className="text-sm text-green-800 mt-1">Consider using "sustainable," "eco-friendly," and "wireless" in your content. These keywords are trending in your category.</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex items-start space-x-3">
                  <i className="fas fa-clock text-amber-600 mt-1"></i>
                  <div>
                    <h4 className="font-medium text-amber-900">Best Posting Time</h4>
                    <p className="text-sm text-amber-800 mt-1">Your audience is most active on weekdays between 2-4 PM. Schedule your social media posts accordingly.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Content Performance</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div>
                  <p className="font-medium text-slate-900">Product Descriptions</p>
                  <p className="text-sm text-slate-600">Avg. engagement: 4.2/5</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-600">+12%</p>
                  <p className="text-xs text-slate-600">vs last month</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div>
                  <p className="font-medium text-slate-900">Social Media Ads</p>
                  <p className="text-sm text-slate-600">Click-through rate: 3.8%</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-600">+8%</p>
                  <p className="text-xs text-slate-600">vs last month</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div>
                  <p className="font-medium text-slate-900">Email Campaigns</p>
                  <p className="text-sm text-slate-600">Open rate: 24.6%</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-red-600">-2%</p>
                  <p className="text-xs text-slate-600">vs last month</p>
                </div>
              </div>
            </div>

            <button className="w-full mt-4 bg-slate-100 text-slate-700 py-2 px-4 rounded-lg font-medium hover:bg-slate-200 transition-colors duration-200">
              View Detailed Analytics
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
