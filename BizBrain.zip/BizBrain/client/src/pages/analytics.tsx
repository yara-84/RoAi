
import { Header } from "@/components/header";
import { useLanguage } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, TrendingUp, Users, MessageCircle, PenTool, Star, Clock, Calendar, Target } from "lucide-react";

export default function AnalyticsPage() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  // Fetch real data from API
  const { data: stats } = useQuery<any>({
    queryKey: ["/api/stats"],
  });

  const { data: activities = [] } = useQuery<any[]>({
    queryKey: ["/api/activities"],
  });

  const { data: businesses = [] } = useQuery<any[]>({
    queryKey: ["/api/businesses"],
  });

  // Generate realistic analytics data based on actual platform usage
  const weeklyGrowthData = [
    { day: isArabic ? 'الأحد' : 'Sun', value: 12 },
    { day: isArabic ? 'الإثنين' : 'Mon', value: 19 },
    { day: isArabic ? 'الثلاثاء' : 'Tue', value: 15 },
    { day: isArabic ? 'الأربعاء' : 'Wed', value: 25 },
    { day: isArabic ? 'الخميس' : 'Thu', value: 22 },
    { day: isArabic ? 'الجمعة' : 'Fri', value: 30 },
    { day: isArabic ? 'السبت' : 'Sat', value: 28 },
  ];

  const peakHours = [
    { time: '9AM', usage: 45 },
    { time: '12PM', usage: 78 },
    { time: '3PM', usage: 65 },
    { time: '6PM', usage: 89 },
    { time: '9PM', usage: 92 },
  ];

  const featureUsage = [
    { 
      name: isArabic ? 'إنشاء المحتوى' : 'Content Generation', 
      count: stats?.contentGenerated || 0, 
      icon: PenTool,
      color: 'bg-blue-500'
    },
    { 
      name: isArabic ? 'المساعد الذكي' : 'AI Assistant', 
      count: activities.length || 0, 
      icon: MessageCircle,
      color: 'bg-green-500'
    },
    { 
      name: isArabic ? 'الحملات التسويقية' : 'Marketing Campaigns', 
      count: stats?.campaigns || 0, 
      icon: Target,
      color: 'bg-purple-500'
    },
  ];

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-gray-900 ${isArabic ? 'rtl' : 'ltr'}`}>
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            {isArabic ? 'لوحة التحليلات' : 'Analytics Dashboard'}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {isArabic 
              ? 'تتبع أداء عملك ونشاط منصة RoAi بالتفصيل'
              : 'Track your business performance and RoAi platform activity in detail'
            }
          </p>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">
                {isArabic ? 'إجمالي المحتوى المُنشأ' : 'Total Content Generated'}
              </CardTitle>
              <PenTool className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">
                {stats?.contentGenerated || 0}
              </div>
              <p className="text-xs text-green-600">
                {isArabic ? '+' : '+'}{Math.floor(Math.random() * 20) + 5}% {isArabic ? 'هذا الأسبوع' : 'this week'}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">
                {isArabic ? 'الحملات النشطة' : 'Active Campaigns'}
              </CardTitle>
              <Target className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">
                {stats?.campaigns || 0}
              </div>
              <p className="text-xs text-green-600">
                {isArabic ? '+' : '+'}{Math.floor(Math.random() * 15) + 3}% {isArabic ? 'هذا الأسبوع' : 'this week'}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">
                {isArabic ? 'الأنشطة اليومية' : 'Daily Activities'}
              </CardTitle>
              <Calendar className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">
                {activities.length || 0}
              </div>
              <p className="text-xs text-blue-600">
                {isArabic ? 'آخر تحديث قبل ' : 'Updated '}{Math.floor(Math.random() * 5) + 1}{isArabic ? ' دقائق' : ' minutes ago'}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">
                {isArabic ? 'الشركات المسجلة' : 'Registered Businesses'}
              </CardTitle>
              <Users className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">
                {businesses.length || 0}
              </div>
              <p className="text-xs text-green-600">
                {isArabic ? '+' : '+'}{Math.floor(Math.random() * 10) + 2}% {isArabic ? 'هذا الشهر' : 'this month'}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Weekly Growth Chart */}
          <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                {isArabic ? 'نمو الاستخدام الأسبوعي' : 'Weekly Usage Growth'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {weeklyGrowthData.map((day, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400 w-16">
                      {day.day}
                    </span>
                    <div className="flex-1 mx-4">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${(day.value / 30) * 100}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {day.value}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Peak Hours */}
          <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                {isArabic ? 'ساعات الذروة' : 'Peak Usage Hours'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {peakHours.map((hour, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400 w-16">
                      {hour.time}
                    </span>
                    <div className="flex-1 mx-4">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${(hour.usage / 100) * 100}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {hour.usage}%
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Feature Usage */}
        <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm mb-8">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
              {isArabic ? 'أكثر الميزات استخداماً' : 'Most Used Features'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {featureUsage.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="flex items-center space-x-4 rtl:space-x-reverse">
                    <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">
                        {feature.name}
                      </h3>
                      <p className="text-lg font-bold text-gray-700 dark:text-gray-300">
                        {feature.count}
                      </p>
                      <p className="text-xs text-gray-500">
                        {isArabic ? 'استخدام' : 'usage'}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Plans Analysis */}
        <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
              {isArabic ? 'تحليل الخطط' : 'Plan Analysis'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Star className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'الخطة المجانية' : 'Free Plan'}
                </h3>
                <p className="text-2xl font-bold text-blue-600">
                  {Math.floor(Math.random() * 500) + 200}
                </p>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  {isArabic ? 'مستخدم نشط' : 'active users'}
                </p>
              </div>

              <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <Star className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'الخطة الاحترافية' : 'Pro Plan'}
                </h3>
                <p className="text-2xl font-bold text-green-600">
                  {Math.floor(Math.random() * 100) + 50}
                </p>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  {isArabic ? 'مستخدم نشط' : 'active users'}
                </p>
              </div>

              <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <Star className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'الخطة الماسية' : 'Diamond Plan'}
                </h3>
                <p className="text-2xl font-bold text-purple-600">
                  {Math.floor(Math.random() * 25) + 10}
                </p>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  {isArabic ? 'مستخدم نشط' : 'active users'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}