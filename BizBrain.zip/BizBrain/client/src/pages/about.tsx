import { Header } from "@/components/header";
import { useLanguage } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, Heart, Shield, Target, Users, Zap } from "lucide-react";

export default function AboutPage() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  const content = {
    en: "RoAi is an AI-powered platform helping merchants grow through automation, creativity, and smart marketing solutions.",
    ar: "روآي هي منصة مدعومة بالذكاء الاصطناعي تساعد التجار على النمو من خلال الأتمتة، الإبداع، وحلول التسويق الذكية."
  };

  const features = [
    {
      icon: Brain,
      title: { en: "AI-Powered Intelligence", ar: "ذكاء اصطناعي متطور" },
      description: { 
        en: "Advanced AI algorithms that understand your business and create personalized content",
        ar: "خوارزميات ذكاء اصطناعي متقدمة تفهم عملك وتنشئ محتوى مخصص"
      }
    },
    {
      icon: Target,
      title: { en: "Marketing Automation", ar: "أتمتة التسويق" },
      description: { 
        en: "Automated campaigns that reach the right audience at the perfect time",
        ar: "حملات آلية تصل للجمهور المناسب في الوقت المثالي"
      }
    },
    {
      icon: Users,
      title: { en: "Merchant-Focused", ar: "مخصص للتجار" },
      description: { 
        en: "Built specifically for Arab merchants with local market understanding",
        ar: "مصمم خصيصاً للتجار العرب مع فهم للسوق المحلي"
      }
    },
    {
      icon: Zap,
      title: { en: "Lightning Fast", ar: "سرعة البرق" },
      description: { 
        en: "Generate professional content in seconds, not hours",
        ar: "إنشاء محتوى احترافي في ثوان، وليس ساعات"
      }
    },
    {
      icon: Heart,
      title: { en: "Built with Care", ar: "مصنوع بعناية" },
      description: { 
        en: "Every feature designed with merchant success in mind",
        ar: "كل ميزة مصممة مع وضع نجاح التاجر في الاعتبار"
      }
    },
    {
      icon: Shield,
      title: { en: "Secure & Reliable", ar: "آمن وموثوق" },
      description: { 
        en: "Enterprise-grade security protecting your business data",
        ar: "أمان على مستوى المؤسسات يحمي بيانات عملك"
      }
    }
  ];

  const stats = [
    { number: "10,000+", label: { en: "Active Merchants", ar: "تاجر نشط" } },
    { number: "500K+", label: { en: "Content Generated", ar: "محتوى مُنشأ" } },
    { number: "50+", label: { en: "Countries Served", ar: "دولة نخدمها" } },
    { number: "99.9%", label: { en: "Uptime Guarantee", ar: "ضمان وقت التشغيل" } }
  ];

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-gray-900 ${isArabic ? 'rtl' : 'ltr'}`}>
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            {isArabic ? 'من نحن' : 'About RoAi'}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed">
            {content[language]}
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white dark:bg-gray-800 border-0 shadow-sm text-center">
              <CardContent className="pt-6">
                <p className="text-3xl font-bold text-blue-600 mb-2">{stat.number}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">{stat.label[language]}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Features Grid */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-12">
            {isArabic ? 'لماذا RoAi؟' : 'Why Choose RoAi?'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="bg-white dark:bg-gray-800 border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                      {feature.title[language]}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                      {feature.description[language]}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Mission Statement */}
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              {isArabic ? 'مهمتنا' : 'Our Mission'}
            </h3>
            <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed mb-6">
              {isArabic 
                ? 'تمكين كل تاجر في الوطن العربي من أدوات الذكاء الاصطناعي المتطورة لبناء أعمال مستدامة ومزدهرة'
                : 'Empowering every merchant in the Arab world with advanced AI tools to build sustainable and thriving businesses'
              }
            </p>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              {isArabic ? 'ابدأ رحلتك معنا' : 'Start Your Journey'}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}