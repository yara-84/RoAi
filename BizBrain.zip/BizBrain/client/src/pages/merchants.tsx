import { useState } from 'react';
import { useLanguage } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, Star, MessageCircle, Mail, Phone, PenTool } from 'lucide-react';

interface PlanFeature {
  en: string;
  ar: string;
}

interface Plan {
  id: string;
  name: { en: string; ar: string };
  description: { en: string; ar: string };
  features: PlanFeature[];
  price: { en: string; ar: string };
  popular?: boolean;
  buttonText: { en: string; ar: string };
}

const plans: Plan[] = [
  {
    id: 'free',
    name: { en: 'Free Plan', ar: 'الخطة المجانية' },
    description: { en: 'Access marketplace services from agencies and freelancers', ar: 'الوصول لخدمات السوق من الوكالات والمستقلين' },
    price: { en: 'Free', ar: 'مجاناً' },
    features: [
      { en: 'Access to marketplace agencies and freelancers', ar: 'الوصول لوكالات ومستقلين في السوق' },
      { en: 'Buy AI tools from marketplace (15% platform fee)', ar: 'شراء أدوات الذكاء الاصطناعي من السوق (رسوم منصة ١٥٪)' },
      { en: 'Basic business profile', ar: 'ملف تجاري أساسي' },
      { en: 'Community support', ar: 'دعم المجتمع' },
      { en: 'No AI tools included', ar: 'لا تشمل أدوات الذكاء الاصطناعي' }
    ],
    buttonText: { en: 'Start Free', ar: 'ابدأ مجاناً' }
  },
  {
    id: 'pro',
    name: { en: 'Pro Plan', ar: 'الخطة الاحترافية' },
    description: { en: 'AI-powered tools with marketplace access', ar: 'أدوات مدعومة بالذكاء الاصطناعي مع الوصول للسوق' },
    price: { en: '$49/month', ar: '٤٩ دولار/شهرياً' },
    popular: true,
    features: [
      { en: 'All Free plan features', ar: 'جميع مميزات الخطة المجانية' },
      { en: 'AI content generation tools', ar: 'أدوات توليد المحتوى بالذكاء الاصطناعي' },
      { en: 'AI chatbot assistant (Saad or Hadeel)', ar: 'مساعد شات بوت ذكي (سعد أو هديل)' },
      { en: '5 AI-generated content pieces per week', ar: '٥ قطع محتوى مولدة بالذكاء الاصطناعي أسبوعياً' },
      { en: 'Priority support', ar: 'دعم أولوية' }
    ],
    buttonText: { en: 'Choose Pro', ar: 'اختر الاحترافية' }
  },
  {
    id: 'diamond',
    name: { en: 'Diamond Plan', ar: 'الخطة الماسية' },
    description: { en: 'Premium AI tools with unlimited access', ar: 'أدوات ذكاء اصطناعي متميزة مع وصول غير محدود' },
    price: { en: '$149/month', ar: '١٤٩ دولار/شهرياً' },
    features: [
      { en: 'All Pro plan features', ar: 'جميع مميزات الخطة الاحترافية' },
      { en: 'Unlimited AI content generation', ar: 'توليد محتوى غير محدود بالذكاء الاصطناعي' },
      { en: 'Advanced AI marketing automation', ar: 'أتمتة تسويقية متقدمة بالذكاء الاصطناعي' },
      { en: 'Personalized AI consultants (Saad & Hadeel)', ar: 'مستشارين ذكيين شخصيين (سعد وهديل)' },
      { en: 'White-label AI tools', ar: 'أدوات ذكاء اصطناعي بعلامتك التجارية' },
      { en: 'Dedicated account manager', ar: 'مدير حساب مخصص' }
    ],
    buttonText: { en: 'Go Diamond', ar: 'اختر الماسية' }
  }
];

export default function MerchantsPage() {
  const { language, t } = useLanguage();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const isArabic = language === 'ar';

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              {isArabic ? 'للتجار والشركات' : 'For Merchants'}
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-8">
              {isArabic 
                ? 'منصة شاملة تعمل بالذكاء الاصطناعي تساعد التجار وأصحاب المشاريع الصغيرة في تطوير أعمالهم من خلال:'
                : 'Comprehensive AI-powered platform helping merchants and small business owners grow their businesses through:'
              }
            </p>
            
            {/* Services List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12 max-w-6xl mx-auto">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <PenTool className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                  {isArabic ? 'إنشاء المحتوى' : 'Content Creation'}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {isArabic ? 'أوصاف منتجات وحملات تسويقية احترافية' : 'Professional product descriptions & marketing campaigns'}
                </p>
              </div>
              
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                  {isArabic ? 'مساعد ذكي شخصي' : 'Personal AI Assistant'}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {isArabic ? 'اختر بين سعد وهديل لدعم أعمالك' : 'Choose between Saad & Hadeel for business support'}
                </p>
              </div>
              
              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Star className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                  {isArabic ? 'سوق متكامل' : 'Integrated Marketplace'}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {isArabic ? 'وكالات ومستقلين وأدوات ذكية في مكان واحد' : 'Agencies, freelancers & AI tools in one place'}
                </p>
              </div>
              
              <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Check className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                  {isArabic ? 'دعم ثنائي اللغة' : 'Bilingual Support'}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {isArabic ? 'العربية والإنجليزية مع دعم RTL كامل' : 'Full Arabic & English with RTL support'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing Plans */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {isArabic ? 'خطط الأسعار' : 'Pricing Plans'}
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            {isArabic 
              ? 'حلول مرنة تناسب احتياجات جميع أنواع الأعمال'
              : 'Flexible solutions to fit every business need'
            }
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <Card 
              key={plan.id} 
              className={`relative transition-all duration-300 hover:shadow-lg ${
                plan.popular ? 'ring-2 ring-blue-600 scale-105' : ''
              } ${selectedPlan === plan.id ? 'ring-2 ring-green-600' : ''}`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-4 py-1">
                  <Star className="w-4 h-4 mr-1" />
                  {isArabic ? 'الأكثر شعبية' : 'Most Popular'}
                </Badge>
              )}
              
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white">
                  {plan.name[language]}
                </CardTitle>
                <p className="text-gray-600 dark:text-gray-400 mt-2">
                  {plan.description[language]}
                </p>
                <div className="mt-4">
                  <span className="text-3xl font-bold text-blue-600">
                    {plan.price[language]}
                  </span>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300 text-sm">
                        {feature[language]}
                      </span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full ${plan.popular ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                  variant={plan.popular ? 'default' : 'outline'}
                  onClick={() => setSelectedPlan(plan.id)}
                >
                  {plan.buttonText[language]}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Contact Section */}
      <div className="bg-gray-50 dark:bg-gray-800 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {isArabic ? 'تحتاج خطة مخصصة؟' : 'Need a Custom Plan?'}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              {isArabic 
                ? 'تواصل معنا لمناقشة احتياجاتك الخاصة والحصول على عرض مخصص يناسب عملك تماماً'
                : 'Contact us to discuss your specific needs and get a custom quote that fits your business perfectly'
              }
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <Mail className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    {isArabic ? 'البريد الإلكتروني' : 'Email Us'}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    contact@roai.com
                  </p>
                </div>
              </div>
              <Button className="w-full" variant="outline">
                <Mail className="w-4 h-4 mr-2" />
                {isArabic ? 'إرسال رسالة' : 'Send Message'}
              </Button>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    {isArabic ? 'المساعد الذكي' : 'AI Assistant'}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {isArabic ? 'تحدث مع مساعدنا الذكي' : 'Chat with our AI assistant'}
                  </p>
                </div>
              </div>
              <Button className="w-full" variant="outline">
                <MessageCircle className="w-4 h-4 mr-2" />
                {isArabic ? 'ابدأ المحادثة' : 'Start Chat'}
              </Button>
            </Card>
          </div>
        </div>
      </div>

      {/* Marketplace Section */}
      <div className="bg-gray-50 dark:bg-gray-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {isArabic ? 'سوق RoAi' : 'RoAi Marketplace'}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              {isArabic 
                ? 'اكتشف مجموعة واسعة من الخدمات والأدوات من وكالات ومستقلين محترفين'
                : 'Discover a wide range of services and tools from professional agencies and freelancers'
              }
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="font-semibold text-xl text-gray-900 dark:text-white mb-2">
                {isArabic ? 'وكالات معتمدة' : 'Certified Agencies'}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {isArabic 
                  ? 'وكالات تسويق معتمدة تقدم خدمات شاملة لعملك'
                  : 'Certified marketing agencies providing comprehensive services for your business'
                }
              </p>
              <Button variant="outline" className="w-full">
                {isArabic ? 'تصفح الوكالات' : 'Browse Agencies'}
              </Button>
            </Card>

            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-semibold text-xl text-gray-900 dark:text-white mb-2">
                {isArabic ? 'مستقلون خبراء' : 'Expert Freelancers'}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {isArabic 
                  ? 'مستقلون متخصصون في التسويق الرقمي وإنشاء المحتوى'
                  : 'Specialized freelancers in digital marketing and content creation'
                }
              </p>
              <Button variant="outline" className="w-full">
                {isArabic ? 'تصفح المستقلين' : 'Browse Freelancers'}
              </Button>
            </Card>

            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-xl text-gray-900 dark:text-white mb-2">
                {isArabic ? 'أدوات ذكية' : 'AI Tools'}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {isArabic 
                  ? 'أدوات ذكاء اصطناعي متخصصة لتحسين عملك'
                  : 'Specialized AI tools to enhance your business operations'
                }
              </p>
              <Button variant="outline" className="w-full">
                {isArabic ? 'تصفح الأدوات' : 'Browse Tools'}
              </Button>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-6 max-w-2xl mx-auto">
              <h4 className="font-semibold text-yellow-800 dark:text-yellow-200 mb-2">
                {isArabic ? 'رسوم المنصة' : 'Platform Fees'}
              </h4>
              <p className="text-yellow-700 dark:text-yellow-300">
                {isArabic 
                  ? 'نحصل على ١٥٪ من قيمة كل عملية شراء شهرياً للمساعدة في تطوير المنصة وتقديم خدمات أفضل'
                  : 'We collect 15% monthly from each purchase to help develop the platform and provide better services'
                }
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Features Highlight */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {isArabic ? 'لماذا تختار RoAi؟' : 'Why Choose RoAi?'}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="font-semibold text-xl text-gray-900 dark:text-white mb-2">
              {isArabic ? 'ذكاء اصطناعي متقدم' : 'Advanced AI Technology'}
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {isArabic 
                ? 'محتوى عالي الجودة مدعوم بأحدث تقنيات الذكاء الاصطناعي'
                : 'High-quality content powered by cutting-edge AI technology'
              }
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="font-semibold text-xl text-gray-900 dark:text-white mb-2">
              {isArabic ? 'مساعدين شخصيين' : 'Personal Assistants'}
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {isArabic 
                ? 'اختر بين سعد وهديل كمساعدين شخصيين بالذكاء الاصطناعي'
                : 'Choose between Saad and Hadeel as your personal AI assistants'
              }
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="font-semibold text-xl text-gray-900 dark:text-white mb-2">
              {isArabic ? 'سوق متكامل' : 'Integrated Marketplace'}
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {isArabic 
                ? 'وصول مباشر لوكالات ومستقلين وأدوات ذكية في مكان واحد'
                : 'Direct access to agencies, freelancers, and AI tools in one place'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}