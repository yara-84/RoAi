import { Header } from "@/components/header";
import { useLanguage } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Lock, Eye, Database, UserCheck, AlertTriangle } from "lucide-react";

export default function PrivacyPolicyPage() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  const mainContent = {
    en: "We protect all merchant data with full compliance to Saudi cybersecurity laws. Data is never shared without consent.",
    ar: "نحمي جميع بيانات التجار بما يتوافق مع أنظمة الأمن السيبراني السعودية. ولا يتم مشاركة أي بيانات دون إذن."
  };

  const sections = [
    {
      icon: Database,
      title: { en: "Data Collection", ar: "جمع البيانات" },
      content: {
        en: "We collect only necessary information to provide our AI services: business details, content preferences, and usage analytics. All data is encrypted and stored securely.",
        ar: "نجمع فقط المعلومات الضرورية لتقديم خدماتنا الذكية: تفاصيل العمل، تفضيلات المحتوى، وتحليلات الاستخدام. جميع البيانات مشفرة ومخزنة بأمان."
      }
    },
    {
      icon: Lock,
      title: { en: "Data Security", ar: "أمان البيانات" },
      content: {
        en: "Your data is protected using industry-standard encryption (AES-256) and secure servers located in compliance-approved data centers within Saudi Arabia.",
        ar: "بياناتك محمية باستخدام تشفير معياري في الصناعة (AES-256) وخوادم آمنة موجودة في مراكز بيانات معتمدة داخل المملكة العربية السعودية."
      }
    },
    {
      icon: UserCheck,
      title: { en: "Data Usage", ar: "استخدام البيانات" },
      content: {
        en: "We use your data solely to improve AI recommendations, generate personalized content, and provide customer support. No data is sold to third parties.",
        ar: "نستخدم بياناتك فقط لتحسين توصيات الذكاء الاصطناعي، وإنشاء محتوى مخصص، وتقديم دعم العملاء. لا نبيع أي بيانات لأطراف ثالثة."
      }
    },
    {
      icon: Eye,
      title: { en: "Data Access", ar: "الوصول للبيانات" },
      content: {
        en: "Only authorized RoAi team members have access to your data, and only when necessary for service delivery or technical support.",
        ar: "فقط أعضاء فريق روآي المخولون لديهم حق الوصول لبياناتك، وفقط عند الضرورة لتقديم الخدمة أو الدعم التقني."
      }
    },
    {
      icon: Shield,
      title: { en: "Compliance", ar: "الامتثال" },
      content: {
        en: "RoAi fully complies with Saudi Data Protection Law, GDPR principles, and international cybersecurity standards (ISO 27001).",
        ar: "روآي تلتزم بالكامل بقانون حماية البيانات السعودي، ومبادئ GDPR، والمعايير الدولية للأمن السيبراني (ISO 27001)."
      }
    },
    {
      icon: AlertTriangle,
      title: { en: "Your Rights", ar: "حقوقك" },
      content: {
        en: "You have the right to access, modify, or delete your data at any time. Contact our support team for data requests or privacy concerns.",
        ar: "لديك الحق في الوصول، تعديل، أو حذف بياناتك في أي وقت. تواصل مع فريق الدعم لطلبات البيانات أو مخاوف الخصوصية."
      }
    }
  ];

  const lastUpdated = isArabic ? "آخر تحديث: يناير 2024" : "Last Updated: January 2024";

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-gray-900 ${isArabic ? 'rtl' : 'ltr'}`}>
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {isArabic ? 'سياسة الخصوصية' : 'Privacy Policy'}
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
            {mainContent[language]}
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500">
            {lastUpdated}
          </p>
        </div>

        {/* Privacy Sections */}
        <div className="space-y-6 mb-12">
          {sections.map((section, index) => {
            const Icon = section.icon;
            return (
              <Card key={index} className="bg-white dark:bg-gray-800 border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3 rtl:space-x-reverse">
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <span className="text-xl font-semibold text-gray-900 dark:text-white">
                      {section.title[language]}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                    {section.content[language]}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Contact Info */}
        <Card className="bg-blue-50 dark:bg-blue-900/20 border-0 shadow-sm">
          <CardContent className="pt-6 text-center">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              {isArabic ? 'أسئلة حول الخصوصية؟' : 'Privacy Questions?'}
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {isArabic 
                ? 'تواصل معنا إذا كان لديك أي استفسارات حول كيفية حمايتنا لبياناتك'
                : 'Contact us if you have any questions about how we protect your data'
              }
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="mailto:privacy@roai.com" 
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                privacy@roai.com
              </a>
              <a 
                href="/support" 
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                {isArabic ? 'مركز الدعم' : 'Support Center'}
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}