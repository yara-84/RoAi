import { Header } from "@/components/header";
import { useLanguage } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Users, CreditCard, AlertCircle, Scale, CheckCircle } from "lucide-react";

export default function TermsOfUsePage() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  const mainContent = {
    en: "RoAi services are provided under fair usage terms. Any misuse or fraud may result in suspension.",
    ar: "يتم تقديم خدمات روآي وفقًا لشروط الاستخدام العادل. أي إساءة استخدام أو احتيال قد يؤدي إلى الإيقاف."
  };

  const terms = [
    {
      icon: Users,
      title: { en: "Account Responsibility", ar: "مسؤولية الحساب" },
      content: {
        en: "You are responsible for maintaining the security of your account credentials. Do not share login information with unauthorized users.",
        ar: "أنت مسؤول عن الحفاظ على أمان بيانات حسابك. لا تشارك معلومات تسجيل الدخول مع مستخدمين غير مخولين."
      }
    },
    {
      icon: CheckCircle,
      title: { en: "Fair Usage Policy", ar: "سياسة الاستخدام العادل" },
      content: {
        en: "Our AI services are designed for legitimate business use. Excessive automated requests or spam generation may result in temporary limitations.",
        ar: "خدماتنا الذكية مصممة للاستخدام التجاري المشروع. الطلبات الآلية المفرطة أو إنشاء الرسائل المزعجة قد يؤدي إلى قيود مؤقتة."
      }
    },
    {
      icon: CreditCard,
      title: { en: "Payment Terms", ar: "شروط الدفع" },
      content: {
        en: "Subscription fees are billed monthly or annually. Refunds are available within 7 days if no AI services were used, per Saudi eCommerce regulations.",
        ar: "رسوم الاشتراك تُحصّل شهرياً أو سنوياً. الاسترجاع متاح خلال 7 أيام بشرط عدم استخدام الخدمات الذكية، وفقاً لأنظمة التجارة الإلكترونية السعودية."
      }
    },
    {
      icon: FileText,
      title: { en: "Content Ownership", ar: "ملكية المحتوى" },
      content: {
        en: "All AI-generated content belongs to you. RoAi does not claim ownership over your business content, but retains rights to improve our AI models.",
        ar: "جميع المحتوى المُنشأ بالذكاء الاصطناعي يخصك. روآي لا تدعي ملكية محتوى عملك، لكنها تحتفظ بحقوق تحسين نماذج الذكاء الاصطناعي."
      }
    },
    {
      icon: AlertCircle,
      title: { en: "Prohibited Activities", ar: "الأنشطة المحظورة" },
      content: {
        en: "Prohibited: Creating harmful, illegal, or fraudulent content. Attempting to reverse-engineer our AI systems. Violating intellectual property rights.",
        ar: "محظور: إنشاء محتوى ضار أو غير قانوني أو احتيالي. محاولة فك تشفير أنظمة الذكاء الاصطناعي. انتهاك حقوق الملكية الفكرية."
      }
    },
    {
      icon: Scale,
      title: { en: "Liability & Disputes", ar: "المسؤولية والنزاعات" },
      content: {
        en: "RoAi provides services 'as-is'. We are not liable for business decisions based on AI recommendations. Disputes are resolved under Saudi Arabian law.",
        ar: "روآي تقدم الخدمات 'كما هي'. نحن غير مسؤولين عن القرارات التجارية المبنية على توصيات الذكاء الاصطناعي. النزاعات تُحل وفقاً للقانون السعودي."
      }
    }
  ];

  const lastUpdated = isArabic ? "آخر تحديث: يناير 2024" : "Last Updated: January 2024";

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-gray-900 ${isArabic ? 'rtl' : 'ltr'}`}>
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {isArabic ? 'شروط الاستخدام' : 'Terms of Use'}
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
            {mainContent[language]}
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500">
            {lastUpdated}
          </p>
        </div>

        {/* Terms Sections */}
        <div className="space-y-6 mb-12">
          {terms.map((term, index) => {
            const Icon = term.icon;
            return (
              <Card key={index} className="bg-white dark:bg-gray-800 border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3 rtl:space-x-reverse">
                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-green-600" />
                    </div>
                    <span className="text-xl font-semibold text-gray-900 dark:text-white">
                      {term.title[language]}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                    {term.content[language]}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Acceptance Notice */}
        <Card className="bg-green-50 dark:bg-green-900/20 border-0 shadow-sm">
          <CardContent className="pt-6 text-center">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              {isArabic ? 'قبول الشروط' : 'Acceptance of Terms'}
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {isArabic 
                ? 'استخدامك لمنصة روآي يعني موافقتك على هذه الشروط. إذا كنت لا توافق، فلا تستخدم خدماتنا.'
                : 'By using RoAi platform, you agree to these terms. If you do not agree, please do not use our services.'
              }
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="/contact" 
                className="text-green-600 hover:text-green-700 font-medium"
              >
                {isArabic ? 'اتصل بنا للاستفسارات' : 'Contact Us for Questions'}
              </a>
              <a 
                href="/privacy-policy" 
                className="text-green-600 hover:text-green-700 font-medium"
              >
                {isArabic ? 'سياسة الخصوصية' : 'Privacy Policy'}
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}