import { Header } from "@/components/header";
import { useLanguage } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle, Mail, Phone, Clock, HelpCircle, BookOpen } from "lucide-react";

export default function SupportPage() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  const mainContent = {
    en: "Our team is here to help you 24/7 via live chat, email, or WhatsApp.",
    ar: "فريقنا متواجد لمساعدتك 24/7 عبر الدردشة المباشرة أو البريد الإلكتروني أو الواتساب."
  };

  const supportChannels = [
    {
      icon: MessageCircle,
      title: { en: "Live Chat", ar: "الدردشة المباشرة" },
      description: { 
        en: "Get instant help from our AI assistant or connect with support agents",
        ar: "احصل على مساعدة فورية من مساعدنا الذكي أو تواصل مع وكلاء الدعم"
      },
      action: { en: "Start Chat", ar: "ابدأ المحادثة" },
      availability: { en: "Available 24/7", ar: "متاح 24/7" },
      color: "bg-blue-500"
    },
    {
      icon: Mail,
      title: { en: "Email Support", ar: "الدعم عبر البريد" },
      description: { 
        en: "Send detailed questions and get comprehensive answers",
        ar: "أرسل أسئلة مفصلة واحصل على إجابات شاملة"
      },
      action: { en: "Send Email", ar: "أرسل رسالة" },
      availability: { en: "Response within 2 hours", ar: "رد خلال ساعتين" },
      color: "bg-green-500"
    },
    {
      icon: Phone,
      title: { en: "WhatsApp Support", ar: "دعم الواتساب" },
      description: { 
        en: "Quick voice or text support via WhatsApp",
        ar: "دعم صوتي أو نصي سريع عبر الواتساب"
      },
      action: { en: "Message on WhatsApp", ar: "راسل عبر الواتساب" },
      availability: { en: "9 AM - 9 PM (GMT+3)", ar: "9 صباحاً - 9 مساءً (GMT+3)" },
      color: "bg-green-600"
    }
  ];

  const faqItems = [
    {
      question: { 
        en: "How do I upgrade my plan?", 
        ar: "كيف أقوم بترقية خطتي؟" 
      },
      answer: { 
        en: "Visit your Profile page and click 'Upgrade Plan' or contact our support team for assistance.",
        ar: "قم بزيارة صفحة الملف الشخصي واضغط على 'ترقية الخطة' أو تواصل مع فريق الدعم للمساعدة."
      }
    },
    {
      question: { 
        en: "Can I get a refund?", 
        ar: "هل يمكنني الحصول على استرداد؟" 
      },
      answer: { 
        en: "Yes, refunds are available within 7 days if you haven't used any AI services, as per Saudi eCommerce regulations.",
        ar: "نعم، الاسترداد متاح خلال 7 أيام إذا لم تستخدم أي خدمات ذكاء اصطناعي، وفقاً لأنظمة التجارة الإلكترونية السعودية."
      }
    },
    {
      question: { 
        en: "Is my data secure?", 
        ar: "هل بياناتي آمنة؟" 
      },
      answer: { 
        en: "Absolutely. We use enterprise-grade security and comply with Saudi cybersecurity laws. Your data is never shared without consent.",
        ar: "بالطبع. نحن نستخدم أمان على مستوى المؤسسات ونتوافق مع قوانين الأمن السيبراني السعودية. بياناتك لا تُشارك أبداً دون إذن."
      }
    },
    {
      question: { 
        en: "How does the AI content generation work?", 
        ar: "كيف يعمل توليد المحتوى بالذكاء الاصطناعي؟" 
      },
      answer: { 
        en: "Our AI analyzes your business details and preferences to create personalized marketing content, product descriptions, and social media posts.",
        ar: "ذكاؤنا الاصطناعي يحلل تفاصيل عملك وتفضيلاتك لإنشاء محتوى تسويقي مخصص، وأوصاف منتجات، ومنشورات وسائل التواصل الاجتماعي."
      }
    }
  ];

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-gray-900 ${isArabic ? 'rtl' : 'ltr'}`}>
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {isArabic ? 'الدعم والمساعدة' : 'Support & Help'}
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            {mainContent[language]}
          </p>
        </div>

        {/* Support Channels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {supportChannels.map((channel, index) => {
            const Icon = channel.icon;
            return (
              <Card key={index} className="bg-white dark:bg-gray-800 border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 ${channel.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">
                    {channel.title[language]}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    {channel.description[language]}
                  </p>
                  <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse text-sm text-gray-500 mb-4">
                    <Clock className="w-4 h-4" />
                    <span>{channel.availability[language]}</span>
                  </div>
                  <Button className="w-full" variant="outline">
                    {channel.action[language]}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* FAQ Section */}
        <div className="mb-16">
          <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse mb-8">
            <HelpCircle className="w-8 h-8 text-blue-600" />
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
              {isArabic ? 'الأسئلة الشائعة' : 'Frequently Asked Questions'}
            </h2>
          </div>
          
          <div className="space-y-4">
            {faqItems.map((item, index) => (
              <Card key={index} className="bg-white dark:bg-gray-800 border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                    {item.question[language]}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                    {item.answer[language]}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Resources Section */}
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center">
            <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse mb-4">
              <BookOpen className="w-8 h-8 text-blue-600" />
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                {isArabic ? 'مصادر إضافية' : 'Additional Resources'}
              </h3>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {isArabic 
                ? 'اكتشف أدلة المستخدم، والبرامج التعليمية، وأفضل الممارسات لتحقيق أقصى استفادة من منصة روآي'
                : 'Explore user guides, tutorials, and best practices to get the most out of RoAi platform'
              }
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="outline" className="bg-white/50">
                {isArabic ? 'دليل المستخدم' : 'User Guide'}
              </Button>
              <Button variant="outline" className="bg-white/50">
                {isArabic ? 'فيديوهات تعليمية' : 'Video Tutorials'}
              </Button>
              <Button variant="outline" className="bg-white/50">
                {isArabic ? 'أفضل الممارسات' : 'Best Practices'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}