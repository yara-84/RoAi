import { useState } from "react";
import { Header } from "@/components/header";
import { useLanguage } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useQuery } from "@tanstack/react-query";
import { 
  User, 
  Building, 
  Globe, 
  MessageCircle, 
  Instagram, 
  Crown, 
  Calendar, 
  TrendingUp, 
  FileText, 
  Upload, 
  Settings, 
  Bell, 
  Trash2,
  Edit3,
  Star,
  PenTool,
  Target,
  Download
} from "lucide-react";

export default function MerchantProfilePage() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const [isEditing, setIsEditing] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([
    { name: 'company-logo.png', type: 'image', date: '2024-01-15', size: '2.3 MB' },
    { name: 'menu-2024.pdf', type: 'document', date: '2024-01-10', size: '1.8 MB' },
    { name: 'brand-guidelines.pdf', type: 'document', date: '2024-01-08', size: '3.2 MB' }
  ]);

  // Fetch real data from API
  const { data: stats } = useQuery<any>({
    queryKey: ["/api/stats"],
  });

  const { data: activities = [] } = useQuery<any[]>({
    queryKey: ["/api/activities"],
  });

  const { data: businesses = [] } = useQuery<any[]>({
    queryKey: ["/api/businesses"],
  });

  const currentBusiness = businesses[0] || {
    name: 'TechBoutique',
    category: 'Electronics',
    description: 'Premium electronics and gadgets store'
  };

  // Mock profile data - in real app this would come from user profile API
  const [profileData, setProfileData] = useState({
    name: currentBusiness.name || 'TechBoutique',
    businessType: currentBusiness.category || 'Electronics',
    city: 'Dubai',
    country: 'UAE',
    bio: isArabic ? 'متجر إلكتروني متخصص في بيع الأجهزة الذكية والإلكترونيات المتطورة' : 'Premium electronics store specializing in smart devices and cutting-edge technology',
    website: 'https://techboutique.ae',
    whatsapp: '+971501234567',
    instagram: '@techboutique_uae',
    profilePicture: '/api/placeholder/150/150'
  });

  const currentPlan = {
    name: isArabic ? 'الخطة الاحترافية' : 'Pro Plan',
    status: isArabic ? 'نشط' : 'Active',
    startDate: '2024-01-01',
    price: '$49/month',
    color: 'bg-green-500'
  };

  const activityStats = [
    {
      label: isArabic ? 'الحملات المُنشأة' : 'Campaigns Created',
      value: stats?.campaigns || 0,
      icon: Target,
      color: 'text-blue-600'
    },
    {
      label: isArabic ? 'المحتوى المُولد' : 'Content Generated',
      value: stats?.contentGenerated || 0,
      icon: PenTool,
      color: 'text-green-600'
    },
    {
      label: isArabic ? 'استخدام الذكاء الاصطناعي' : 'AI Tools Used',
      value: activities.length || 0,
      icon: Star,
      color: 'text-purple-600'
    }
  ];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const newFile = {
        name: file.name,
        type: file.type.includes('image') ? 'image' : 'document',
        date: new Date().toISOString().split('T')[0],
        size: `${(file.size / 1024 / 1024).toFixed(1)} MB`
      };
      setUploadedFiles([newFile, ...uploadedFiles]);
    }
  };

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-gray-900 ${isArabic ? 'rtl' : 'ltr'}`}>
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            {isArabic ? 'الملف الشخصي للتاجر' : 'Merchant Profile'}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {isArabic 
              ? 'إدارة معلومات حسابك وتفاصيل عملك'
              : 'Manage your account information and business details'
            }
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Profile & Subscription */}
          <div className="space-y-6">
            {/* Basic Info */}
            <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'المعلومات الأساسية' : 'Basic Information'}
                </CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  <Edit3 className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Profile Picture */}
                <div className="text-center">
                  <div className="w-24 h-24 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-3">
                    <User className="w-12 h-12 text-blue-600" />
                  </div>
                  {isEditing && (
                    <Button variant="outline" size="sm">
                      {isArabic ? 'تغيير الصورة' : 'Change Photo'}
                    </Button>
                  )}
                </div>

                {/* Basic Info Fields */}
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {isArabic ? 'اسم التاجر' : 'Merchant Name'}
                    </Label>
                    {isEditing ? (
                      <Input 
                        value={profileData.name}
                        onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                        className="mt-1"
                      />
                    ) : (
                      <p className="mt-1 font-medium text-gray-900 dark:text-white">{profileData.name}</p>
                    )}
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {isArabic ? 'نوع العمل' : 'Business Type'}
                    </Label>
                    {isEditing ? (
                      <Input 
                        value={profileData.businessType}
                        onChange={(e) => setProfileData({...profileData, businessType: e.target.value})}
                        className="mt-1"
                      />
                    ) : (
                      <p className="mt-1 text-gray-900 dark:text-white">{profileData.businessType}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {isArabic ? 'المدينة' : 'City'}
                      </Label>
                      {isEditing ? (
                        <Input 
                          value={profileData.city}
                          onChange={(e) => setProfileData({...profileData, city: e.target.value})}
                          className="mt-1"
                        />
                      ) : (
                        <p className="mt-1 text-gray-900 dark:text-white">{profileData.city}</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {isArabic ? 'البلد' : 'Country'}
                      </Label>
                      {isEditing ? (
                        <Input 
                          value={profileData.country}
                          onChange={(e) => setProfileData({...profileData, country: e.target.value})}
                          className="mt-1"
                        />
                      ) : (
                        <p className="mt-1 text-gray-900 dark:text-white">{profileData.country}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {isArabic ? 'نبذة مختصرة' : 'Short Bio'}
                    </Label>
                    {isEditing ? (
                      <Textarea 
                        value={profileData.bio}
                        onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
                        maxLength={250}
                        className="mt-1"
                        rows={3}
                      />
                    ) : (
                      <p className="mt-1 text-gray-600 dark:text-gray-400 text-sm">{profileData.bio}</p>
                    )}
                  </div>

                  {/* Contact Links */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900 dark:text-white">
                      {isArabic ? 'روابط التواصل' : 'Contact Links'}
                    </h4>
                    
                    {[
                      { icon: Globe, label: isArabic ? 'الموقع الإلكتروني' : 'Website', key: 'website' },
                      { icon: MessageCircle, label: isArabic ? 'واتساب' : 'WhatsApp', key: 'whatsapp' },
                      { icon: Instagram, label: isArabic ? 'انستغرام' : 'Instagram', key: 'instagram' }
                    ].map((link) => {
                      const Icon = link.icon;
                      return (
                        <div key={link.key} className="flex items-center space-x-3 rtl:space-x-reverse">
                          <Icon className="w-4 h-4 text-gray-500" />
                          {isEditing ? (
                            <Input 
                              value={profileData[link.key as keyof typeof profileData]}
                              onChange={(e) => setProfileData({...profileData, [link.key]: e.target.value})}
                              placeholder={link.label}
                              className="flex-1"
                            />
                          ) : (
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {profileData[link.key as keyof typeof profileData] || `${isArabic ? 'غير محدد' : 'Not set'}`}
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {isEditing && (
                    <div className="flex space-x-3 rtl:space-x-reverse pt-4">
                      <Button 
                        onClick={() => setIsEditing(false)}
                        className="flex-1"
                      >
                        {isArabic ? 'حفظ التغييرات' : 'Save Changes'}
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => setIsEditing(false)}
                        className="flex-1"
                      >
                        {isArabic ? 'إلغاء' : 'Cancel'}
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Subscription Overview */}
            <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'نظرة عامة على الاشتراك' : 'Subscription Overview'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{currentPlan.name}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{currentPlan.price}</p>
                  </div>
                  <Badge className={`${currentPlan.color} text-white`}>
                    <Crown className="w-3 h-3 mr-1" />
                    {currentPlan.status}
                  </Badge>
                </div>
                
                <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600 dark:text-gray-400">
                  <Calendar className="w-4 h-4" />
                  <span>
                    {isArabic ? 'بدأ في' : 'Started'}: {currentPlan.startDate}
                  </span>
                </div>

                <Button className="w-full" variant="outline">
                  {isArabic ? 'ترقية الخطة' : 'Upgrade Plan'}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Activity & Files */}
          <div className="lg:col-span-2 space-y-6">
            {/* Business Activity */}
            <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'نشاط العمل' : 'Business Activity'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  {activityStats.map((stat, index) => {
                    const Icon = stat.icon;
                    return (
                      <div key={index} className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <Icon className={`w-8 h-8 ${stat.color} mx-auto mb-2`} />
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
                      </div>
                    );
                  })}
                </div>

                {/* Simple Performance Graph */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 dark:text-white">
                    {isArabic ? 'الأداء الأسبوعي' : 'Weekly Performance'}
                  </h4>
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                    const value = Math.floor(Math.random() * 80) + 20;
                    return (
                      <div key={day} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400 w-12">{day}</span>
                        <div className="flex-1 mx-4">
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                              style={{ width: `${value}%` }}
                            />
                          </div>
                        </div>
                        <span className="text-sm font-medium text-gray-900 dark:text-white w-8">{value}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Merchant Files */}
            <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'ملفات التاجر' : 'Merchant Files'}
                </CardTitle>
                <label htmlFor="file-upload">
                  <Button asChild variant="outline" size="sm">
                    <span>
                      <Upload className="w-4 h-4 mr-2" />
                      {isArabic ? 'رفع ملف' : 'Upload File'}
                    </span>
                  </Button>
                </label>
                <input
                  id="file-upload"
                  type="file"
                  onChange={handleFileUpload}
                  className="hidden"
                  accept=".pdf,.doc,.docx,.png,.jpg,.jpeg"
                />
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="flex items-center space-x-3 rtl:space-x-reverse">
                        <div className={`w-8 h-8 rounded flex items-center justify-center ${
                          file.type === 'image' ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'
                        }`}>
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white text-sm">{file.name}</p>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            {file.date} • {file.size}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Settings */}
            <Card className="bg-white dark:bg-gray-800 border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                  {isArabic ? 'الإعدادات' : 'Settings'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="w-4 h-4 mr-3" />
                    {isArabic ? 'تعديل الملف الشخصي' : 'Edit Profile'}
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start">
                    <Crown className="w-4 h-4 mr-3" />
                    {isArabic ? 'إدارة الخطة' : 'Manage Plan'}
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start">
                    <Bell className="w-4 h-4 mr-3" />
                    {isArabic ? 'إعدادات الإشعارات' : 'Notification Settings'}
                  </Button>
                  
                  <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                    <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20">
                      <Trash2 className="w-4 h-4 mr-3" />
                      {isArabic ? 'حذف الحساب' : 'Delete Account'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}