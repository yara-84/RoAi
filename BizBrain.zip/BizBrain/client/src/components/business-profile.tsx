import { Business } from "@shared/schema";

interface BusinessProfileProps {
  business: Business | null;
  onBusinessChange: (business: Business) => void;
}

export function BusinessProfile({ business }: BusinessProfileProps) {
  if (!business) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Business Profile</h3>
        <p className="text-slate-600 text-sm">No business profile found. Create one to get started.</p>
      </div>
    );
  }

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">Business Profile</h3>
      <div className="space-y-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">{getInitials(business.name)}</span>
          </div>
          <div>
            <h4 className="font-medium text-slate-900">{business.name}</h4>
            <p className="text-sm text-slate-600">{business.category}</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">Profile Completion</span>
            <span className="font-medium text-slate-900">85%</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div className="bg-accent-500 h-2 rounded-full" style={{ width: '85%' }}></div>
          </div>
        </div>

        <button className="w-full text-left p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors duration-200">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-slate-700">Update Business Info</span>
            <i className="fas fa-chevron-right text-slate-400 text-xs"></i>
          </div>
        </button>
      </div>
    </div>
  );
}
