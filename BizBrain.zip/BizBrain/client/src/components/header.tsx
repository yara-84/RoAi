import { useLanguage } from "@/lib/i18n";
import { LanguageSwitcher } from "./language-switcher";
import { Link, useLocation } from 'wouter';
import { Home, PenTool, MessageCircle, BarChart3, User } from 'lucide-react';
import logoPath from '@assets/IMG_1487_1754072471164.png';

export function Header() {
  const { t } = useLanguage();
  const [location] = useLocation();

  const navItems = [
    { href: '/', label: t('nav.dashboard'), icon: Home },
    { href: '/ai-chat', label: t('nav.aiChat'), icon: MessageCircle },
    { href: '/merchants', label: t('nav.merchants'), icon: PenTool },
    { href: '/analytics', label: t('nav.analytics'), icon: BarChart3 },
    { href: '/profile', label: t('nav.profile'), icon: User }
  ];

  return (
    <header className="bg-white dark:bg-gray-900 border-b border-slate-200 dark:border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8 rtl:space-x-reverse">
            <Link href="/" className="flex items-center space-x-3 rtl:space-x-reverse">
              <img src={logoPath} alt="RoAi Logo" className="h-10 w-auto" />
            </Link>
            
            <nav className="hidden md:flex space-x-6 rtl:space-x-reverse">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive
                        ? 'text-blue-600 bg-blue-50 dark:text-blue-400 dark:bg-blue-900/20'
                        : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </nav>
          </div>
          
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <LanguageSwitcher />
          </div>
        </div>
      </div>
    </header>
  );
}
