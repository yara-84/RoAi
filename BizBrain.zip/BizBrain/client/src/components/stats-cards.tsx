import { useQuery } from "@tanstack/react-query";

interface Stats {
  contentGenerated: number;
  campaigns: number;
  suggestions: number;
  timeSaved: string;
}

export function StatsCards() {
  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 animate-pulse">
            <div className="h-4 bg-slate-200 rounded mb-2"></div>
            <div className="h-8 bg-slate-200 rounded mb-4"></div>
            <div className="h-3 bg-slate-200 rounded w-20"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-slate-600 text-sm font-medium">Content Generated</p>
            <p className="text-2xl font-bold text-slate-900">{stats?.contentGenerated || 0}</p>
          </div>
          <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
            <i className="fas fa-file-alt text-primary-600"></i>
          </div>
        </div>
        <div className="mt-4">
          <span className="text-accent-600 text-sm font-medium">↗ 12% this month</span>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-slate-600 text-sm font-medium">Campaigns Created</p>
            <p className="text-2xl font-bold text-slate-900">{stats?.campaigns || 0}</p>
          </div>
          <div className="w-12 h-12 bg-secondary-100 rounded-lg flex items-center justify-center">
            <i className="fas fa-bullhorn text-secondary-600"></i>
          </div>
        </div>
        <div className="mt-4">
          <span className="text-accent-600 text-sm font-medium">↗ 8% this month</span>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-slate-600 text-sm font-medium">AI Suggestions</p>
            <p className="text-2xl font-bold text-slate-900">{stats?.suggestions || 0}</p>
          </div>
          <div className="w-12 h-12 bg-accent-100 rounded-lg flex items-center justify-center">
            <i className="fas fa-lightbulb text-accent-600"></i>
          </div>
        </div>
        <div className="mt-4">
          <span className="text-accent-600 text-sm font-medium">↗ 23% this month</span>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-slate-600 text-sm font-medium">Time Saved</p>
            <p className="text-2xl font-bold text-slate-900">{stats?.timeSaved || '0h'}</p>
          </div>
          <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
            <i className="fas fa-clock text-amber-600"></i>
          </div>
        </div>
        <div className="mt-4">
          <span className="text-accent-600 text-sm font-medium">↗ 15% this month</span>
        </div>
      </div>
    </div>
  );
}
