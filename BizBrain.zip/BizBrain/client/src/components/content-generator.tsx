import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { contentGenerationSchema, type ContentGenerationRequest, type Business } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ContentGeneratorProps {
  currentBusiness: Business | null;
}

interface GeneratedContent {
  content: string;
  hashtags?: string[];
  suggestions?: string[];
  id: string;
}

export function ContentGenerator({ currentBusiness }: ContentGeneratorProps) {
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const { toast } = useToast();
  const { t, language } = useLanguage();
  const queryClient = useQueryClient();

  const form = useForm<ContentGenerationRequest>({
    resolver: zodResolver(contentGenerationSchema),
    defaultValues: {
      type: 'product-description',
      productInfo: '',
      targetAudience: currentBusiness?.targetAudience || '',
      tone: 'professional',
      businessId: currentBusiness?.id,
      language: language,
    },
  });

  const generateContentMutation = useMutation({
    mutationFn: async (data: ContentGenerationRequest) => {
      const response = await apiRequest('POST', '/api/content/generate', data);
      return response.json() as Promise<GeneratedContent>;
    },
    onSuccess: (data) => {
      setGeneratedContent(data);
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      toast({
        title: t('success.contentGenerated'),
        description: t('success.contentReady'),
      });
    },
    onError: (error) => {
      console.error('Content generation error:', error);
      toast({
        title: t('error.generationFailed'),
        description: error instanceof Error ? error.message : "Failed to generate content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContentGenerationRequest) => {
    generateContentMutation.mutate({
      ...data,
      businessId: currentBusiness?.id,
    });
  };

  const copyToClipboard = async () => {
    if (generatedContent?.content) {
      try {
        await navigator.clipboard.writeText(generatedContent.content);
        toast({
          title: t('success.copied'),
          description: t('success.copiedDesc'),
        });
      } catch (error) {
        toast({
          title: t('error.copyFailed'),
          description: t('error.copyFailedDesc'),
          variant: "destructive",
        });
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-900 mb-4">Quick Content Generation</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button 
            onClick={() => form.setValue('type', 'product-description')}
            className="p-4 bg-gradient-to-r from-primary-50 to-primary-100 border border-primary-200 rounded-lg hover:from-primary-100 hover:to-primary-200 transition-all duration-200 text-left group"
          >
            <div className="flex items-center space-x-3 mb-2">
              <i className="fas fa-shopping-bag text-primary-600 text-lg"></i>
              <h3 className="font-semibold text-slate-900">Product Description</h3>
            </div>
            <p className="text-slate-600 text-sm">Generate compelling product descriptions that convert</p>
          </button>

          <button 
            onClick={() => form.setValue('type', 'social-ad')}
            className="p-4 bg-gradient-to-r from-secondary-50 to-secondary-100 border border-secondary-200 rounded-lg hover:from-secondary-100 hover:to-secondary-200 transition-all duration-200 text-left group"
          >
            <div className="flex items-center space-x-3 mb-2">
              <i className="fas fa-share-alt text-secondary-600 text-lg"></i>
              <h3 className="font-semibold text-slate-900">Social Media Ad</h3>
            </div>
            <p className="text-slate-600 text-sm">Create engaging social media advertisements</p>
          </button>

          <button 
            onClick={() => form.setValue('type', 'hashtags')}
            className="p-4 bg-gradient-to-r from-accent-50 to-accent-100 border border-accent-200 rounded-lg hover:from-accent-100 hover:to-accent-200 transition-all duration-200 text-left group"
          >
            <div className="flex items-center space-x-3 mb-2">
              <i className="fas fa-hashtag text-accent-600 text-lg"></i>
              <h3 className="font-semibold text-slate-900">Hashtag Generator</h3>
            </div>
            <p className="text-slate-600 text-sm">Discover trending hashtags for your niche</p>
          </button>

          <button 
            onClick={() => form.setValue('type', 'marketing-strategy')}
            className="p-4 bg-gradient-to-r from-amber-50 to-amber-100 border border-amber-200 rounded-lg hover:from-amber-100 hover:to-amber-200 transition-all duration-200 text-left group"
          >
            <div className="flex items-center space-x-3 mb-2">
              <i className="fas fa-chart-line text-amber-600 text-lg"></i>
              <h3 className="font-semibold text-slate-900">Marketing Strategy</h3>
            </div>
            <p className="text-slate-600 text-sm">Get AI-powered marketing recommendations</p>
          </button>
        </div>
      </div>

      {/* Content Creation Form */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-900 mb-4">AI Content Generator</h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Content Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select content type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="product-description">Product Description</SelectItem>
                      <SelectItem value="social-ad">Social Media Ad</SelectItem>
                      <SelectItem value="email-marketing">Email Marketing</SelectItem>
                      <SelectItem value="blog-post">Blog Post</SelectItem>
                      <SelectItem value="customer-support">Customer Support Response</SelectItem>
                      <SelectItem value="hashtags">Hashtags</SelectItem>
                      <SelectItem value="marketing-strategy">Marketing Strategy</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="productInfo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product/Business Information</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe your product, service, or provide key details for content generation..."
                      className="resize-none"
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="targetAudience"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('content.targetAudience')}</FormLabel>
                    <FormControl>
                      <Input
                        placeholder={t('content.targetAudiencePlaceholder')}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="tone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('content.tone')}</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select tone" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="professional">{t('tone.professional')}</SelectItem>
                        <SelectItem value="casual">{t('tone.casual')}</SelectItem>
                        <SelectItem value="enthusiastic">{t('tone.enthusiastic')}</SelectItem>
                        <SelectItem value="luxury">{t('tone.luxury')}</SelectItem>
                        <SelectItem value="technical">{t('tone.technical')}</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="language"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('content.language')}</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="en">{t('language.english')}</SelectItem>
                        <SelectItem value="ar">{t('language.arabic')}</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button 
              type="submit" 
              className="w-full"
              disabled={generateContentMutation.isPending}
            >
              {generateContentMutation.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Generating Content...
                </>
              ) : (
                <>
                  <i className="fas fa-magic mr-2"></i>
                  Generate Content with AI
                </>
              )}
            </Button>
          </form>
        </Form>
      </div>

      {/* Generated Content Preview */}
      {generatedContent && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-slate-900">Generated Content</h2>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={copyToClipboard}>
                <i className="fas fa-copy mr-1"></i>Copy
              </Button>
              <Button variant="outline" size="sm">
                <i className="fas fa-download mr-1"></i>Export
              </Button>
            </div>
          </div>
          
          <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
            <div className="text-slate-800 leading-relaxed whitespace-pre-wrap">
              {generatedContent.content}
            </div>
          </div>

          {generatedContent.hashtags && generatedContent.hashtags.length > 0 && (
            <div className="mt-4">
              <h4 className="font-medium text-slate-900 mb-2">Suggested Hashtags:</h4>
              <div className="flex flex-wrap gap-2">
                {generatedContent.hashtags.map((hashtag, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-blue-100 text-blue-700 rounded-md text-sm"
                  >
                    {hashtag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {generatedContent.suggestions && generatedContent.suggestions.length > 0 && (
            <div className="mt-4">
              <h4 className="font-medium text-slate-900 mb-2">Optimization Suggestions:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600">
                {generatedContent.suggestions.map((suggestion, index) => (
                  <li key={index}>{suggestion}</li>
                ))}
              </ul>
            </div>
          )}
          
          {/* Content Enhancement Options */}
          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="outline" size="sm">
              Make it shorter
            </Button>
            <Button variant="outline" size="sm">
              Add more details
            </Button>
            <Button variant="outline" size="sm">
              Change tone
            </Button>
            <Button variant="outline" size="sm" onClick={() => form.handleSubmit(onSubmit)()}>
              Regenerate
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
