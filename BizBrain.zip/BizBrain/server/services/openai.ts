import OpenAI from "openai";
import { ContentGenerationRequest } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const apiKey = process.env.OPENAI_API_KEY?.trim() || "sk-fallback-key";

// Validate API key format and clean it
const cleanApiKey = apiKey.replace(/[^\x00-\x7F]/g, ""); // Remove non-ASCII characters

const openai = new OpenAI({ 
  apiKey: cleanApiKey
});

export class ContentGenerationService {
  async generateContent(request: ContentGenerationRequest): Promise<{
    content: string;
    hashtags?: string[];
    suggestions?: string[];
  }> {
    // Check if we have a valid API key format
    const hasValidKey = cleanApiKey && cleanApiKey.startsWith('sk-') && cleanApiKey.length > 20 && cleanApiKey.length < 200;
    
    if (!hasValidKey) {
      console.warn("Invalid or missing OpenAI API key, returning demo content");
      return this.generateDemoContent(request);
    }

    try {
      const prompt = this.buildPrompt(request);
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert marketing copywriter and content creator for e-commerce businesses. Create compelling, conversion-focused content that engages the target audience. Always respond in JSON format."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 1000,
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result;
    } catch (error) {
      console.error("OpenAI API Error:", error);
      console.log("Falling back to demo content due to API error");
      return this.generateDemoContent(request);
    }
  }

  private generateDemoContent(request: ContentGenerationRequest): {
    content: string;
    hashtags?: string[];
    suggestions?: string[];
  } {
    const { type, productInfo, tone, language = 'en' } = request;
    const isArabic = language === 'ar';
    
    switch (type) {
      case 'product-description':
        return {
          content: isArabic ? 
            `اكتشف الأفضل في ${productInfo}! يجمع هذا المنتج المميز بين التكنولوجيا المتطورة والتصميم الأنيق ليقدم أداءً استثنائياً. سواء كنت محترفاً أو هاوياً، ستقدر الاهتمام بالتفاصيل والحرفية العالية التي تدخل في كل وحدة.

المميزات الرئيسية:
• تكنولوجيا متقدمة للأداء المتفوق
• تصميم مريح للاستخدام المريح
• مواد مميزة للمتانة
• إعداد سهل وواجهة سهلة الاستخدام

حوّل تجربتك اليوم مع هذه الإضافة الضرورية لمجموعتك. لا تشتري منتجاً فحسب - استثمر في الجودة التي تحقق النتائج.` :
            `Experience the ultimate in ${productInfo.toLowerCase()}! This premium product combines cutting-edge technology with elegant design to deliver exceptional performance. Whether you're a professional or enthusiast, you'll appreciate the attention to detail and superior craftsmanship that goes into every unit.

Key Features:
• Advanced technology for superior performance
• Ergonomic design for comfortable use
• Premium materials for durability
• Easy setup and user-friendly interface

Transform your experience today with this must-have addition to your collection. Don't just buy a product – invest in quality that delivers results.`,
          suggestions: isArabic ? [
            "أضف المواصفات التقنية المحددة",
            "اشمل شهادات العملاء",
            "سلط الضوء على نقاط البيع الفريدة",
            "أضف معلومات الضمان"
          ] : [
            "Add specific technical specifications",
            "Include customer testimonials",
            "Highlight unique selling points",
            "Add warranty information"
          ]
        };

      case 'social-ad':
        return {
          content: isArabic ?
            `🚀 هل أنت مستعد لترقية ${productInfo}؟

هذا المنتج المبتكر ينفد من رفوفنا بسرعة! انضم إلى آلاف العملاء الراضين الذين قاموا بالتبديل بالفعل.

✨ جودة مميزة مضمونة
🔥 عرض محدود الوقت  
💫 شحن مجاني متاح

لا تنتظر - ${productInfo} المثالي على بُعد نقرة واحدة!

تسوق الآن واختبر الفرق! 👆` :
            `🚀 Ready to upgrade your ${productInfo.toLowerCase()}? 

This game-changing product is flying off our shelves! Join thousands of satisfied customers who've already made the switch.

✨ Premium quality guaranteed
🔥 Limited-time offer
💫 Free shipping available

Don't wait – your perfect ${productInfo.toLowerCase()} is just one click away!

Shop now and experience the difference! 👆`,
          hashtags: isArabic ? 
            ["#مميز", "#جودة", "#ضروري", "#ترقية", "#تسوق", "#عرض"] :
            ["#premium", "#quality", "#musthave", "#upgrade", "#shopping", "#deal"],
          suggestions: isArabic ? [
            "أضف إلحاحاً مع مؤقت العد التنازلي",
            "اشمل مراجعات العملاء",
            "استخدم هاشتاغات خاصة بالمنصة"
          ] : [
            "Add urgency with countdown timer",
            "Include customer reviews",
            "Use platform-specific hashtags"
          ]
        };

      case 'hashtags':
        return {
          content: "Here are trending hashtags for your niche based on current market analysis and engagement patterns.",
          hashtags: ["#trending", "#viral", "#musthave", "#premium", "#quality", "#lifestyle", "#innovation", "#gamechanging", "#exclusive", "#limited"]
        };

      case 'marketing-strategy':
        return {
          content: `Marketing Strategy for ${productInfo}

1. Target Audience Analysis
- Identify core demographics and psychographics
- Create detailed buyer personas
- Map customer journey touchpoints

2. Channel Strategy
- Social Media: Focus on visual platforms (Instagram, TikTok)
- Email Marketing: Nurture sequences and product launches
- Content Marketing: Educational blog posts and tutorials
- Paid Advertising: Targeted Google and Facebook ads

3. Messaging Framework
- Core value proposition: Premium quality meets affordability
- Key benefits: Performance, reliability, style
- Emotional triggers: Success, confidence, belonging

4. Implementation Timeline
- Month 1: Setup and content creation
- Month 2: Launch campaigns and optimize
- Month 3: Scale successful initiatives

5. Success Metrics
- Brand awareness: Social media reach and mentions
- Engagement: Click-through rates and social interactions
- Conversions: Sales and email signups`,
          suggestions: [
            "Conduct competitor analysis",
            "Set up marketing automation",
            "Create brand guidelines",
            "Plan seasonal campaigns"
          ]
        };

      default:
        return {
          content: `Professional ${type.replace('-', ' ')} content for ${productInfo}. This high-quality content is designed to engage your target audience and drive results for your business.`,
          suggestions: ["Customize content for your specific needs", "Add call-to-action", "Include contact information"]
        };
    }
  }

  private buildPrompt(request: ContentGenerationRequest): string {
    const { type, productInfo, targetAudience, tone, language = 'en' } = request;
    
    const isArabic = language === 'ar';
    const languageInstruction = isArabic ? 
      'Please respond in Arabic language. Ensure proper Arabic grammar, cultural context, and marketing appeal for Arabic-speaking audiences.' :
      'Please respond in English language.';
    
    const basePrompt = `Create ${type.replace('-', ' ')} content for an e-commerce business.

${languageInstruction}

Product/Business Info: ${productInfo}
${targetAudience ? `Target Audience: ${targetAudience}` : ''}
${tone ? `Tone: ${tone}` : 'Tone: professional'}

Please respond with a JSON object containing:`;

    switch (type) {
      case 'product-description':
        return `${basePrompt}
{
  "content": "A compelling product description with key features and benefits",
  "suggestions": ["optimization tip 1", "optimization tip 2", "optimization tip 3"]
}`;

      case 'social-ad':
        return `${basePrompt}
{
  "content": "Engaging social media ad copy with a strong call-to-action",
  "hashtags": ["#relevant", "#hashtags", "#for", "#the", "#post"],
  "suggestions": ["platform-specific tips"]
}`;

      case 'hashtags':
        return `${basePrompt}
{
  "hashtags": ["#trending", "#relevant", "#hashtags", "#for", "#this", "#niche"],
  "content": "Brief explanation of hashtag strategy and best practices"
}`;

      case 'marketing-strategy':
        return `${basePrompt}
{
  "content": "Comprehensive marketing strategy recommendations including channels, messaging, and tactics",
  "suggestions": ["actionable step 1", "actionable step 2", "actionable step 3"]
}`;

      case 'email-marketing':
        return `${basePrompt}
{
  "content": "Professional email marketing content with subject line and body text",
  "suggestions": ["email optimization tips"]
}`;

      case 'customer-support':
        return `${basePrompt}
{
  "content": "Professional customer support response template",
  "suggestions": ["customer service best practices"]
}`;

      default:
        return `${basePrompt}
{
  "content": "Professional marketing content for the specified type",
  "suggestions": ["relevant optimization tips"]
}`;
    }
  }

  async generateHashtags(niche: string, count: number = 20): Promise<string[]> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a social media expert. Generate relevant, trending hashtags for businesses. Respond with JSON only."
          },
          {
            role: "user",
            content: `Generate ${count} relevant hashtags for the ${niche} niche. Include a mix of broad and specific hashtags. Respond with JSON: {"hashtags": ["#hashtag1", "#hashtag2", ...]}`
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.8,
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result.hashtags || [];
    } catch (error) {
      console.error("Hashtag generation error:", error);
      throw new Error("Failed to generate hashtags");
    }
  }

  async generateChatResponse(message: string, language: string = 'en'): Promise<string> {
    try {
      const isArabic = language === 'ar';
      
      // Extract assistant type from message if provided
      let assistantType = 'saad'; // default
      let cleanMessage = message;
      
      if (message.startsWith('saad:') || message.startsWith('hadeel:')) {
        assistantType = message.split(':')[0];
        cleanMessage = message.split(':').slice(1).join(':').trim();
      }
      
      const assistantPersonality = assistantType === 'saad' ? {
        ar: {
          name: 'سعد',
          personality: 'أنا سعد، مساعدك الذكي للأعمال. أتميز بالطابع المهني والمباشر، وأركز على تقديم حلول عملية وفعالة. أساعدك في:',
          style: 'كن مهنياً ومباشراً في إجاباتك، مع التركيز على الحلول العملية والاستراتيجيات الفعالة.'
        },
        en: {
          name: 'Saad',
          personality: 'I\'m Saad, your AI business assistant. I have a professional and direct approach, focusing on practical solutions and effective strategies. I help you with:',
          style: 'Be professional and direct in your responses, focusing on practical solutions and effective strategies.'
        }
      } : {
        ar: {
          name: 'هديل',
          personality: 'أنا هديل، مساعدتك الذكية للأعمال. أتميز بالطابع الودود والمتفهم، وأركز على تقديم المساعدة الشخصية والدعم. أساعدك في:',
          style: 'كوني ودودة ومتفهمة في إجاباتك، مع التركيز على الدعم الشخصي والمساعدة التفصيلية.'
        },
        en: {
          name: 'Hadeel',
          personality: 'I\'m Hadeel, your AI business assistant. I have a friendly and understanding approach, focusing on personalized help and support. I help you with:',
          style: 'Be friendly and understanding in your responses, focusing on personalized support and detailed assistance.'
        }
      };
      
      const assistant = assistantPersonality[language as 'ar' | 'en'];
      
      const systemPrompt = isArabic ?
        `${assistant.personality}
- استراتيجيات التسويق وخطط الحملات
- كتابة المحتوى وأوصاف المنتجات
- وسائل التواصل الاجتماعي والإعلان
- تحليل المنافسين واتجاهات السوق
- نصائح الأعمال والاستراتيجيات
- خدمة العملاء وإدارة العلاقات

${assistant.style} اجب دائماً بالعربية وقدم نصائح عملية ومفيدة.` :
        `${assistant.personality}
- Marketing strategies and campaign planning
- Content creation and product descriptions
- Social media and advertising
- Competitor analysis and market trends
- Business advice and strategies
- Customer service and relationship management

${assistant.style} Always provide practical, actionable advice.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: cleanMessage
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      });

      return response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try again.";
      
    } catch (error) {
      console.error("OpenAI API Error:", error);
      const isArabic = language === 'ar';
      return isArabic ?
        `شكراً لك على رسالتك! أنا مساعد الأعمال الذكي وأساعدك في أسئلة الأعمال والتسويق. يرجى المحاولة مرة أخرى أو إعادة صياغة سؤالك.` :
        `Thank you for your message! I'm your AI business assistant here to help with business and marketing questions. Please try again or rephrase your question.`;
    }
  }
}

export const contentGenerationService = new ContentGenerationService();
