import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { contentGenerationService } from "./services/openai";
import { contentGenerationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get dashboard stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Get businesses
  app.get("/api/businesses", async (req, res) => {
    try {
      const businesses = await storage.getBusinesses();
      res.json(businesses);
    } catch (error) {
      console.error("Error fetching businesses:", error);
      res.status(500).json({ message: "Failed to fetch businesses" });
    }
  });

  // Get business by ID
  app.get("/api/businesses/:id", async (req, res) => {
    try {
      const business = await storage.getBusiness(req.params.id);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      res.json(business);
    } catch (error) {
      console.error("Error fetching business:", error);
      res.status(500).json({ message: "Failed to fetch business" });
    }
  });

  // Create business
  app.post("/api/businesses", async (req, res) => {
    try {
      const businessData = req.body;
      const business = await storage.createBusiness(businessData);
      res.status(201).json(business);
    } catch (error) {
      console.error("Error creating business:", error);
      res.status(500).json({ message: "Failed to create business" });
    }
  });

  // Update business
  app.patch("/api/businesses/:id", async (req, res) => {
    try {
      const business = await storage.updateBusiness(req.params.id, req.body);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      res.json(business);
    } catch (error) {
      console.error("Error updating business:", error);
      res.status(500).json({ message: "Failed to update business" });
    }
  });

  // Generate content
  app.post("/api/content/generate", async (req, res) => {
    try {
      const validatedData = contentGenerationSchema.parse(req.body);
      
      const result = await contentGenerationService.generateContent(validatedData);
      
      // Save generated content
      const savedContent = await storage.createContent({
        businessId: validatedData.businessId || null,
        type: validatedData.type,
        prompt: validatedData.productInfo,
        content: result.content,
        metadata: {
          targetAudience: validatedData.targetAudience,
          tone: validatedData.tone,
          hashtags: result.hashtags,
          suggestions: result.suggestions,
        }
      });

      // Create activity record
      if (validatedData.businessId) {
        await storage.createActivity({
          businessId: validatedData.businessId,
          type: "content-generated",
          description: `${validatedData.type.replace('-', ' ')} generated`,
          metadata: { contentId: savedContent.id, contentType: validatedData.type }
        });
      }

      res.json({ ...result, id: savedContent.id });
    } catch (error) {
      console.error("Content generation error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate content" 
      });
    }
  });

  // Get content by business
  app.get("/api/businesses/:id/content", async (req, res) => {
    try {
      const content = await storage.getContentByBusiness(req.params.id);
      res.json(content);
    } catch (error) {
      console.error("Error fetching content:", error);
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  // Get all content
  app.get("/api/content", async (req, res) => {
    try {
      const content = await storage.getAllContent();
      res.json(content);
    } catch (error) {
      console.error("Error fetching content:", error);
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  // Get recent activities
  app.get("/api/activities", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const activities = await storage.getRecentActivities(limit);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Get activities by business
  app.get("/api/businesses/:id/activities", async (req, res) => {
    try {
      const activities = await storage.getActivitiesByBusiness(req.params.id);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Generate hashtags
  app.post("/api/hashtags/generate", async (req, res) => {
    try {
      const { niche, count = 20 } = req.body;
      if (!niche) {
        return res.status(400).json({ message: "Niche is required" });
      }

      const hashtags = await contentGenerationService.generateHashtags(niche, count);
      res.json({ hashtags });
    } catch (error) {
      console.error("Hashtag generation error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate hashtags" 
      });
    }
  });

  // AI Chat
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, language = 'en' } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: 'Message is required' });
      }
      
      const response = await contentGenerationService.generateChatResponse(message, language);
      
      // Log chat activity
      await storage.createActivity({
        businessId: 'default-business',
        type: 'chat-interaction',
        description: 'AI chat conversation',
        metadata: { userMessage: message.substring(0, 100) }
      });
      
      res.json({ message: response });
    } catch (error) {
      console.error('Chat error:', error);
      res.status(500).json({ 
        message: 'Failed to process chat message' 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
