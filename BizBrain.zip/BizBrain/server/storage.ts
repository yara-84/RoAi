import { type Business, type InsertBusiness, type Content, type InsertContent, type Activity, type InsertActivity } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Business operations
  getBusiness(id: string): Promise<Business | undefined>;
  getBusinesses(): Promise<Business[]>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  updateBusiness(id: string, business: Partial<InsertBusiness>): Promise<Business | undefined>;

  // Content operations
  getContent(id: string): Promise<Content | undefined>;
  getContentByBusiness(businessId: string): Promise<Content[]>;
  createContent(content: InsertContent): Promise<Content>;
  getAllContent(): Promise<Content[]>;

  // Activity operations
  getActivitiesByBusiness(businessId: string): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  getRecentActivities(limit?: number): Promise<Activity[]>;

  // Stats
  getStats(): Promise<{
    contentGenerated: number;
    campaigns: number;
    suggestions: number;
    timeSaved: string;
  }>;
}

export class MemStorage implements IStorage {
  private businesses: Map<string, Business>;
  private content: Map<string, Content>;
  private activities: Map<string, Activity>;

  constructor() {
    this.businesses = new Map();
    this.content = new Map();
    this.activities = new Map();

    // Initialize with a default business
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    const defaultBusiness = await this.createBusiness({
      name: "TechBoutique",
      category: "Electronics & Gadgets",
      description: "Premium electronics and tech accessories for modern consumers",
      targetAudience: "Tech enthusiasts, professionals, 25-45 years old",
      website: "https://techboutique.com"
    });

    // Add some sample activities
    await this.createActivity({
      businessId: defaultBusiness.id,
      type: "content-generated",
      description: "Product description generated",
      metadata: { contentType: "product-description", title: "Wireless Gaming Mouse" }
    });

    await this.createActivity({
      businessId: defaultBusiness.id,
      type: "content-generated", 
      description: "Social media ad created",
      metadata: { contentType: "social-ad", platform: "Instagram" }
    });
  }

  async getBusiness(id: string): Promise<Business | undefined> {
    return this.businesses.get(id);
  }

  async getBusinesses(): Promise<Business[]> {
    return Array.from(this.businesses.values());
  }

  async createBusiness(insertBusiness: InsertBusiness): Promise<Business> {
    const id = randomUUID();
    const business: Business = {
      ...insertBusiness,
      id,
      createdAt: new Date(),
    };
    this.businesses.set(id, business);
    return business;
  }

  async updateBusiness(id: string, updateData: Partial<InsertBusiness>): Promise<Business | undefined> {
    const existing = this.businesses.get(id);
    if (!existing) return undefined;

    const updated: Business = { ...existing, ...updateData };
    this.businesses.set(id, updated);
    return updated;
  }

  async getContent(id: string): Promise<Content | undefined> {
    return this.content.get(id);
  }

  async getContentByBusiness(businessId: string): Promise<Content[]> {
    return Array.from(this.content.values()).filter(
      (content) => content.businessId === businessId
    );
  }

  async createContent(insertContent: InsertContent): Promise<Content> {
    const id = randomUUID();
    const content: Content = {
      ...insertContent,
      id,
      createdAt: new Date(),
    };
    this.content.set(id, content);
    return content;
  }

  async getAllContent(): Promise<Content[]> {
    return Array.from(this.content.values());
  }

  async getActivitiesByBusiness(businessId: string): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter((activity) => activity.businessId === businessId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const activity: Activity = {
      ...insertActivity,
      id,
      createdAt: new Date(),
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getRecentActivities(limit: number = 10): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async getStats() {
    const totalContent = this.content.size;
    const activities = Array.from(this.activities.values());
    const campaigns = activities.filter(a => a.type === 'campaign-created').length;
    
    return {
      contentGenerated: totalContent,
      campaigns: Math.max(campaigns, Math.floor(totalContent / 5)), // Estimate campaigns
      suggestions: totalContent * 12, // Estimate suggestions
      timeSaved: `${Math.floor(totalContent * 2.5)}h`, // Estimate time saved
    };
  }
}

export const storage = new MemStorage();
