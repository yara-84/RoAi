import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const businesses = pgTable("businesses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  targetAudience: text("target_audience"),
  website: text("website"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const contentGenerated = pgTable("content_generated", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  businessId: varchar("business_id").references(() => businesses.id),
  type: text("type").notNull(), // 'product-description', 'social-ad', 'email', etc.
  prompt: text("prompt").notNull(),
  content: text("content").notNull(),
  metadata: jsonb("metadata"), // stores additional info like tone, audience, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const activities = pgTable("activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  businessId: varchar("business_id").references(() => businesses.id),
  type: text("type").notNull(),
  description: text("description").notNull(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBusinessSchema = createInsertSchema(businesses).omit({
  id: true,
  createdAt: true,
});

export const insertContentSchema = createInsertSchema(contentGenerated).omit({
  id: true,
  createdAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export type InsertBusiness = z.infer<typeof insertBusinessSchema>;
export type Business = typeof businesses.$inferSelect;
export type InsertContent = z.infer<typeof insertContentSchema>;
export type Content = typeof contentGenerated.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// Content generation request schema
export const contentGenerationSchema = z.object({
  type: z.enum(['product-description', 'social-ad', 'email-marketing', 'blog-post', 'customer-support', 'hashtags', 'marketing-strategy']),
  productInfo: z.string().min(10, "Please provide detailed product/business information"),
  targetAudience: z.string().optional(),
  tone: z.enum(['professional', 'casual', 'enthusiastic', 'luxury', 'technical']).optional(),
  businessId: z.string().optional(),
  language: z.enum(['en', 'ar']).default('en'),
});

export type ContentGenerationRequest = z.infer<typeof contentGenerationSchema>;
